# -*- coding: utf-8 -*-
"""
Created on Sun Nov  6 09:09:34 2022

@author: DELL
"""

file=open("test.txt","r")
print("No. of lines in test.txt file is", len(file.readlines()))